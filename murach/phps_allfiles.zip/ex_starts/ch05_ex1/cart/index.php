<?php include '../view/header.php'; ?>

<div id="main">
    <h1 class="top">Shopping Cart - under construction</h1>
</div>

<?php include '../view/footer.php'; ?>
