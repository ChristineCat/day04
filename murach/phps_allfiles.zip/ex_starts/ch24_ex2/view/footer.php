        </div><!-- end main -->
        <div id="footer">
            <p class="copyright">
                &copy; <?php echo date("Y"); ?> My Guitar Shop, Inc.
            </p>
        </div><!-- end footer -->
    </div><!-- end page -->
    </body>
</html>